// Test script to debug database connection issues
// Run with: node scripts/db-connection-test.mjs

// Import environment variables from .env
import { config } from "dotenv";
import pg from "pg";

// Initialize dotenv
config();

const { Client } = pg;

/**
 * Parse a connection string manually into components
 * @param {string} connectionString - Database connection string
 */
function parseConnectionString(connectionString) {
	console.log(
		"Original connection string (masked):",
		connectionString.replace(/:[^@]+@/, ":********@"),
	);

	try {
		// Extract components using regex
		// Format: postgresql://username:password@host:port/database
		const regex = /postgresql:\/\/([^:]+):([^@]+)@([^:]+):(\d+)\/(.+)/;
		const match = connectionString.match(regex);

		if (!match) {
			console.error(
				"Regex match failed. Connection string doesn't match expected format.",
			);
			throw new Error("Invalid connection string format");
		}

		// Extract connection parameters
		const [, username, encodedPassword, host, port, database] = match;

		// Check for problematic characters in password
		const hasPercentSign = encodedPassword.includes("%");

		// Log details about the password
		console.log("Password analysis:");
		console.log("- Length:", encodedPassword.length);
		console.log("- Contains % character:", hasPercentSign);
		console.log("- Encoded password:", encodedPassword);
		console.log("- Username:", username);
		console.log("- Host:", host);
		console.log("- Port:", port);
		console.log("- Database:", database);

		// If it contains %, try to determine if it's an encoded character
		if (hasPercentSign) {
			const percentIndices = [];
			for (let i = 0; i < encodedPassword.length; i++) {
				if (encodedPassword[i] === "%") percentIndices.push(i);
			}

			console.log("- % characters found at positions:", percentIndices);

			// Check if any % is followed by two hex digits (likely URL encoding)
			const encodedChars = percentIndices.filter((i) => {
				return (
					i + 2 < encodedPassword.length &&
					/^[0-9A-Fa-f]{2}$/.test(encodedPassword.substring(i + 1, i + 3))
				);
			});

			if (encodedChars.length > 0) {
				console.log(
					"- Possible URL-encoded characters found at positions:",
					encodedChars,
				);
			}
		}

		return {
			username,
			password: encodedPassword,
			host,
			port: Number.parseInt(port, 10),
			database,
		};
	} catch (error) {
		console.error("Error parsing connection string:", error);
		throw error;
	}
}

/**
 * Test database connection with the given parameters
 */
async function testConnection(params, label) {
	console.log(`\n----- Testing connection: ${label} -----`);

	const client = new Client(params);

	try {
		console.log("Attempting to connect...");
		await client.connect();
		console.log("✅ Connection successful!");

		// Try a simple query
		console.log("Executing test query...");
		const result = await client.query("SELECT current_database() as db_name");
		console.log(
			`✅ Query successful. Connected to database: ${result.rows[0].db_name}`,
		);

		return true;
	} catch (error) {
		console.error("❌ Connection failed:", error.message);
		return false;
	} finally {
		try {
			await client.end();
			console.log("Connection closed");
		} catch (e) {
			// Ignore close errors
		}
	}
}

/**
 * Main function to run all tests
 */
async function runTests() {
	console.log("=== Database Connection Testing ===");

	const connectionString = process.env.DATABASE_URL;
	if (!connectionString) {
		console.error("ERROR: DATABASE_URL not found in environment variables");
		return;
	}

	// Parse the connection string
	const parsed = parseConnectionString(connectionString);

	// Test 1: Using the connection string directly
	await testConnection({ connectionString }, "Original connection string");

	// Test 2: Using parsed parameters directly (no URL decoding)
	await testConnection(
		{
			host: parsed.host,
			port: parsed.port,
			database: parsed.database,
			user: parsed.username,
			password: parsed.password,
		},
		"Parsed parameters (no URL decoding)",
	);

	// Test 3: Try with URL-decoded password
	try {
		const decodedPassword = decodeURIComponent(parsed.password);

		if (decodedPassword !== parsed.password) {
			console.log("\nThe password contains URL-encoded characters.");
			console.log("Original:", parsed.password);
			console.log("Decoded:", decodedPassword);

			await testConnection(
				{
					host: parsed.host,
					port: parsed.port,
					database: parsed.database,
					user: parsed.username,
					password: decodedPassword,
				},
				"Parsed parameters (with URL-decoded password)",
			);
		} else {
			console.log("\nThe password does not contain URL-encoded characters.");
		}
	} catch (error) {
		console.error("Error decoding the password:", error);
	}

	// Test 4: Try with double-encoding if there's a % in the password
	if (parsed.password.includes("%")) {
		try {
			console.log("\nTrying with double-encoded password (for comparison)");
			const doubleEncodedPassword = encodeURIComponent(parsed.password);
			console.log("Double-encoded:", doubleEncodedPassword);

			await testConnection(
				{
					host: parsed.host,
					port: parsed.port,
					database: parsed.database,
					user: parsed.username,
					password: doubleEncodedPassword,
				},
				"Parsed parameters (with double-encoded password)",
			);
		} catch (error) {
			console.error("Error with double-encoding test:", error);
		}
	}
}

// Run the tests
runTests().catch((error) => {
	console.error("Fatal error:", error);
	process.exit(1);
});
