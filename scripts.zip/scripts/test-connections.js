// Test database connections
import { createBrowserClient } from "../src/lib/supabase.js";
import { db } from "../src/server/db/index.js";

async function testConnections() {
	// Test Supabase
	try {
		const supabase = createBrowserClient();
		const { data, error } = await supabase.from("users").select("count");
		console.log("Supabase connection success:", data);
	} catch (e) {
		console.error("Supabase connection failed:", e);
	}

	// Test Drizzle
	try {
		const result = await db.query.users.findMany();
		console.log("Drizzle connection success:", result);
	} catch (e) {
		console.error("Drizzle connection failed:", e);
	}
}

testConnections();
