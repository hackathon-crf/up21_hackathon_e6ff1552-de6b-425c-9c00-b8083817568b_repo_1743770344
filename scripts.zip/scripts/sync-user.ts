// Script to manually sync a user from Supabase Auth to the database
// Usage: pnpm tsx scripts/sync-user.ts <user_id>

import { createClient } from "@supabase/supabase-js";
import { eq } from "drizzle-orm";
import { db } from "../src/server/db";
import { users } from "../src/server/db/schema";

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY; // This should be the service role key, not the anon key

async function syncUser(userId: string) {
	if (!SUPABASE_URL || !SUPABASE_SERVICE_KEY) {
		console.error(
			"Missing Supabase credentials. Set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY",
		);
		return;
	}

	console.log(`Attempting to sync user with ID: ${userId}`);

	// Initialize Supabase admin client
	const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY, {
		auth: {
			autoRefreshToken: false,
			persistSession: false,
		},
	});

	try {
		// First check if user already exists in our database
		const existingUser = await db
			.select()
			.from(users)
			.where(eq(users.id, userId))
			.limit(1)
			.then((rows) => rows[0] || null);

		if (existingUser) {
			console.log(
				`User already exists in database: ${JSON.stringify(existingUser)}`,
			);
			return existingUser;
		}

		// Get user from Supabase Auth
		const { data: authUser, error } =
			await supabase.auth.admin.getUserById(userId);

		if (error || !authUser?.user) {
			console.error(
				"Error fetching user from Supabase:",
				error || "User not found",
			);
			return;
		}

		// Insert user into our database
		console.log(`Creating user record for: ${authUser.user.email}`);
		const newUser = await db
			.insert(users)
			.values({
				id: authUser.user.id,
				email: authUser.user.email || "",
			})
			.returning();

		console.log(`User created successfully: ${JSON.stringify(newUser[0])}`);
		return newUser[0];
	} catch (error) {
		console.error("Error syncing user:", error);
	}
}

// Main execution
const userId = process.argv[2];
if (!userId) {
	console.error(
		"Please provide a user ID as argument: pnpm tsx scripts/sync-user.ts <user_id>",
	);
	process.exit(1);
}

syncUser(userId)
	.then(() => process.exit(0))
	.catch((error) => {
		console.error("Fatal error:", error);
		process.exit(1);
	});
