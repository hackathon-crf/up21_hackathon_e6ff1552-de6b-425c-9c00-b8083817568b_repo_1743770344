// This script diagnoses database connection issues by testing both
// the Supabase direct client and the Drizzle ORM connections

import { createClient } from "@supabase/supabase-js";
import dotenv from "dotenv";
import postgres from "postgres";

// Load environment variables from .env file
dotenv.config();

// Access environment variables directly
const env = {
	NEXT_PUBLIC_SUPABASE_URL: process.env.NEXT_PUBLIC_SUPABASE_URL || "",
	NEXT_PUBLIC_SUPABASE_ANON_KEY:
		process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "",
	SUPABASE_SERVICE_ROLE_KEY: process.env.SUPABASE_SERVICE_ROLE_KEY || "",
	DATABASE_URL: process.env.DATABASE_URL || "",
};

async function runDiagnosis() {
	console.log("🔍 RUNNING DATABASE CONNECTION DIAGNOSIS");
	console.log("=======================================");

	// 1. Test environment variables availability
	console.log("\n📋 CHECKING ENVIRONMENT VARIABLES:");
	console.log(
		"NEXT_PUBLIC_SUPABASE_URL:",
		env.NEXT_PUBLIC_SUPABASE_URL ? "✅ Available" : "❌ Missing",
	);
	console.log(
		"NEXT_PUBLIC_SUPABASE_ANON_KEY:",
		env.NEXT_PUBLIC_SUPABASE_ANON_KEY ? "✅ Available" : "❌ Missing",
	);
	console.log(
		"SUPABASE_SERVICE_ROLE_KEY:",
		env.SUPABASE_SERVICE_ROLE_KEY ? "✅ Available" : "❌ Missing",
	);
	console.log(
		"DATABASE_URL:",
		env.DATABASE_URL ? "✅ Available" : "❌ Missing",
	);

	// 2. Test direct Supabase connection (used by dashboard)
	console.log("\n🔌 TESTING DIRECT SUPABASE CONNECTION (DASHBOARD METHOD):");
	try {
		// Using createClient from @supabase/supabase-js instead of createServerClient
		const supabase = createClient(
			env.NEXT_PUBLIC_SUPABASE_URL,
			env.SUPABASE_SERVICE_ROLE_KEY,
			{
				auth: {
					persistSession: false,
				},
			},
		);

		console.log("Supabase client created successfully");

		// Test a simple query
		const { data, error } = await supabase
			.from("flashcard_deck")
			.select("count");

		if (error) {
			console.error("❌ Supabase query failed:", error.message);
			console.error("Error details:", error);
		} else {
			console.log("✅ Supabase query successful!");
			console.log("Query result:", data);
		}
	} catch (err) {
		console.error(
			"❌ Supabase client creation failed:",
			err instanceof Error ? err.message : String(err),
		);
		if (err instanceof Error && err.stack) {
			console.error("Error stack:", err.stack);
		}
	}

	// 3. Test direct Postgres connection (to validate DB credentials)
	console.log("\n🔌 TESTING DIRECT POSTGRES CONNECTION:");
	let postgresClient = null;
	try {
		// Create a direct postgres connection to validate credentials
		if (env.DATABASE_URL) {
			postgresClient = postgres(env.DATABASE_URL, {
				max: 1,
				ssl:
					process.env.NODE_ENV === "production"
						? { rejectUnauthorized: false }
						: undefined,
			});

			console.log("Direct Postgres client created successfully");

			// Test a simple query
			const result = await postgresClient`SELECT COUNT(*) FROM flashcard_deck`;

			console.log("✅ Direct Postgres query successful!");
			console.log("Query result:", result);
		} else {
			console.error(
				"❌ Cannot test Postgres directly: DATABASE_URL is missing",
			);
		}
	} catch (err) {
		console.error(
			"❌ Postgres connection failed:",
			err instanceof Error ? err.message : String(err),
		);
		if (err instanceof Error && err.stack) {
			console.error("Error stack:", err.stack);
		}
	} finally {
		// Close postgres connection
		if (postgresClient) {
			try {
				await postgresClient.end();
				console.log("Postgres connection closed");
			} catch (err) {
				console.error("Error closing postgres connection:", String(err));
			}
		}
	}

	// 4. Check database file structure instead of trying to import TypeScript
	console.log("\n🔌 CHECKING DATABASE MODULE STRUCTURE:");
	try {
		// Use the already imported fs and path modules
		const { promises: fs } = await import("fs");
		const path = await import("path");

		// Check if the TypeScript files exist
		const dbDirPath = path.resolve(process.cwd(), "src/server/db");
		console.log(`Checking for database files in: ${dbDirPath}`);

		const files = await fs.readdir(dbDirPath);
		console.log("Found database files:", files);

		// Check for index.ts and schema.ts
		const hasIndexFile = files.includes("index.ts");
		const hasSchemaFile = files.includes("schema.ts");

		if (hasIndexFile) {
			console.log("✅ index.ts file found in db directory");

			// Read the index.ts file to check for exports
			const indexContent = await fs.readFile(
				path.join(dbDirPath, "index.ts"),
				"utf8",
			);

			if (indexContent.includes("export const db")) {
				console.log("✅ db export found in index.ts");
			} else {
				console.log("❌ No db export found in index.ts");
			}

			if (indexContent.includes("export const sql")) {
				console.log("✅ sql export found in index.ts");
			} else {
				console.log("❌ No sql export found in index.ts");
			}
		} else {
			console.error("❌ index.ts file not found in db directory");
		}

		if (hasSchemaFile) {
			console.log("✅ schema.ts file found in db directory");

			// Read the schema.ts file to check table definitions
			const schemaContent = await fs.readFile(
				path.join(dbDirPath, "schema.ts"),
				"utf8",
			);

			// Simple scan for table definitions
			const tablesMatch = schemaContent.match(/export const (\w+)\s*=/g) || [];
			console.log("Potential table definitions found:", tablesMatch.length);

			// Extract table names from matches
			const tableNames = tablesMatch
				.map((match) => {
					const nameMatch = match.match(/export const (\w+)\s*=/);
					return nameMatch ? nameMatch[1] : "";
				})
				.filter(Boolean);

			console.log("Defined tables:", tableNames);
		} else {
			console.error("❌ schema.ts file not found in db directory");
		}
	} catch (err) {
		console.error(
			"❌ Drizzle module import failed:",
			err instanceof Error ? err.message : String(err),
		);
		if (err instanceof Error && err.stack) {
			console.error("Error stack:", err.stack);
		}
	}

	console.log("\n📝 DIAGNOSIS SUMMARY:");
	console.log(
		"1. If Supabase connection works but direct Postgres fails: The issue might be with your database credentials",
	);
	console.log(
		"2. If Drizzle module fails to load: The issue might be with your project structure or imports",
	);
	console.log(
		"3. If all module loading works but queries fail in flashcards/chat pages: The issue might be in your tRPC routes",
	);
	console.log(
		"4. If direct DB connections work but tRPC fails: The issue might be in your authentication layer",
	);
}

// Run the diagnosis and handle any errors
runDiagnosis()
	.then(() => {
		console.log("\n✅ Diagnosis complete");
		process.exit(0);
	})
	.catch((err) => {
		console.error(
			"\n❌ Diagnosis script failed:",
			err instanceof Error ? err.message : String(err),
		);
		if (err instanceof Error && err.stack) {
			console.error("Error stack:", err.stack);
		}
		process.exit(1);
	});
