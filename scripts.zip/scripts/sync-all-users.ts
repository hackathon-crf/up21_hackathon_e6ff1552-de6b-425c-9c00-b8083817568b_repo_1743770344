// Script to sync all users from Supabase Auth to the database
// Usage: pnpm tsx scripts/sync-all-users.ts

import { createClient } from "@supabase/supabase-js";
import { eq } from "drizzle-orm";
import { db } from "../src/server/db";
import { users } from "../src/server/db/schema";

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY; // This should be the service role key, not the anon key

async function syncAllUsers() {
	if (!SUPABASE_URL || !SUPABASE_SERVICE_KEY) {
		console.error(
			"Missing Supabase credentials. Set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY",
		);
		process.exit(1);
	}

	console.log("Starting user synchronization...");

	// Initialize Supabase admin client
	const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY, {
		auth: {
			autoRefreshToken: false,
			persistSession: false,
		},
	});

	try {
		// Get all users from Supabase Auth
		const { data: authUsers, error } = await supabase.auth.admin.listUsers();

		if (error) {
			console.error("Error fetching users from Supabase:", error);
			return;
		}

		console.log(`Found ${authUsers.users.length} users in Supabase Auth`);

		// Get existing users from our database
		const existingUsers = await db.select().from(users);

		const existingUserIds = new Set(existingUsers.map((user) => user.id));
		console.log(`Found ${existingUsers.length} users in application database`);

		// Filter out users that already exist in our database
		const usersToSync = authUsers.users.filter(
			(user) => !existingUserIds.has(user.id),
		);
		console.log(`Need to sync ${usersToSync.length} users`);

		if (usersToSync.length === 0) {
			console.log("All users are already synchronized. Nothing to do.");
			return;
		}

		// Insert new users in batches
		const batchSize = 50;
		let syncedCount = 0;

		for (let i = 0; i < usersToSync.length; i += batchSize) {
			const batch = usersToSync.slice(i, i + batchSize);

			const valuesToInsert = batch.map((user) => ({
				id: user.id,
				email: user.email || "",
				created_at: user.created_at ? new Date(user.created_at) : new Date(),
				updated_at: new Date(),
			}));

			await db.insert(users).values(valuesToInsert);

			syncedCount += batch.length;
			console.log(
				`Progress: ${syncedCount}/${usersToSync.length} users synchronized`,
			);
		}

		console.log(
			`Successfully synchronized ${syncedCount} users to the database`,
		);
	} catch (error) {
		console.error("Error syncing users:", error);
	}
}

// Main execution
syncAllUsers()
	.then(() => process.exit(0))
	.catch((error) => {
		console.error("Fatal error:", error);
		process.exit(1);
	});
